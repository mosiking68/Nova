package com.nova.game;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.*;
import android.view.*;
import java.util.*;

public class MainActivity extends Activity {
    GameView game;
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().getDecorView().setSystemUiVisibility(0); game=new GameView(); setContentView(game);}
    @Override public void onBackPressed(){ if(game.stage>=0){game.stage=-1; game.invalidate();} else super.onBackPressed(); }

    class GameView extends View {
        Paint p=new Paint(3); Canvas c; SharedPreferences pref;
        int stage=-1, task=0, score=0, mistakes=0; boolean completed=false;
        float sx,sy; String feedback=""; int selected=-1;
        int[] optionOrder={0,1,2}; Random random=new Random();
        void shuffleOptions(){
          optionOrder=new int[]{0,1,2};
          for(int i=optionOrder.length-1;i>0;i--){int j=random.nextInt(i+1);int t=optionOrder[i];optionOrder[i]=optionOrder[j];optionOrder[j]=t;}
        }
        String[] names={"مدار روشنایی","مونتاژ خودروی برقی","انرژی خورشیدی","رانندگی ایمن","مأموریت مریخ","شبکه اجتماعی امن","هوش مصنوعی و کنترل هوشمند","ساخت و برنامه‌ریزی ربات"};
        String[][] qs={
          {"برای روشن شدن لامپ چه چیزی لازم است؟","مدار بسته","سیم قطع‌شده","لامپ خاموش"},
          {"کدام بخش انرژی را در خودرو نگه می‌دارد؟","باتری","آینه","صندلی"},
          {"پنل خورشیدی چه چیزی را به برق تبدیل می‌کند؟","نور خورشید","صدا","بادِ پنکه"},
          {"چراغ راهنمایی قرمز است؛ چه کار می‌کنی؟","توقف می‌کنم","سرعت را زیاد می‌کنم","از چراغ رد می‌شوم"},
          {"برای فرود امن روی مریخ چه باید کرد؟","کاهش سرعت و فرود کنترل‌شده","خاموش کردن همه سامانه‌ها","برخورد سریع با زمین"},
          {"دوستت عکس خصوصی فرستاده؛ قبل از انتشار چه می‌کنی؟","اجازه می‌گیرم","بدون اجازه منتشر می‌کنم","برای همه می‌فرستم"},
          {"هوش مصنوعی برای تصمیم‌گیری بهتر به چه چیزی نیاز دارد؟","داده مناسب و بررسی انسان","حدس بدون اطلاعات","اطلاعات شخصی همه افراد"},
          {"برای شروع ساخت ربات، کدام بخش پایه و نگهدارنده قطعات است؟","شاسی و بدنه ربات","چرخ یدکی خودرو","پنل خورشیدی"}
        };
        String[][] opts={
          {"مدار بسته","سیم قطع‌شده","لامپ خاموش"},
          {"باتری","آینه","صندلی"},
          {"نور خورشید","صدا","بادِ پنکه"},
          {"توقف می‌کنم","سرعت را زیاد می‌کنم","از چراغ رد می‌شوم"},
          {"کاهش سرعت و فرود کنترل‌شده","خاموش کردن همه سامانه‌ها","برخورد سریع با زمین"},
          {"اجازه می‌گیرم","بدون اجازه منتشر می‌کنم","برای همه می‌فرستم"},
          {"داده مناسب و بررسی انسان","حدس بدون اطلاعات","اطلاعات شخصی همه افراد"},
          {"شاسی و بدنه ربات","چرخ یدکی خودرو","پنل خورشیدی"}
        };
        String[] explain={
          "وقتی مدار کامل و بسته باشد، جریان برق می‌تواند از لامپ عبور کند.",
          "باتری انرژی الکتریکی را ذخیره می‌کند و به موتور می‌رساند.",
          "پنل خورشیدی نور خورشید را به انرژی الکتریکی تبدیل می‌کند.",
          "در چراغ قرمز باید پشت خط توقف بایستی.",
          "فرودگر باید سرعت را کنترل کند تا سالم روی سطح مریخ بنشیند.",
          "حریم خصوصی مهم است؛ برای انتشار عکس دیگران اجازه بگیر.",
          "هوش مصنوعی از داده‌ها الگو یاد می‌گیرد؛ انسان باید نتیجه‌های مهم را بررسی کند.",
          "ربات از شاسی، حسگر، موتور و برنامه تشکیل می‌شود. حسگرها محیط را می‌سنجند و برنامه باید فرمان ایمن بدهد."
        };
        int[] correct={0,0,0,0,0,0,0,0};
        GameView(){super(MainActivity.this); pref=getSharedPreferences("nova_progress",0); setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void text(String s,float x,float y,int size,int color){p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextAlign(Paint.Align.CENTER);c.drawText(s,x,y,p);}
        void round(float l,float t,float r,float b,int color){p.setColor(color);c.drawRoundRect(l,t,r,b,24,24,p);}
        @Override protected void onDraw(Canvas canvas){c=canvas; sx=getWidth(); sy=getHeight(); c.drawColor(Color.rgb(12,22,39));
          text("NOVA",sx/2,65,38,Color.WHITE); text("یادگیری با بازی",sx/2,100,17,0xff9cc9d5);
          if(stage<0){home();return;} play();
        }
        void home(){
          text("سلام! من نووا هستم.",sx/2,155,23,Color.WHITE);
          text("یک مأموریت را انتخاب کن",sx/2,190,16,0xffb8c8d8);
          float top=205, h=Math.min(66,(sy-235)/8f);
          for(int i=0;i<8;i++){float y=top+i*h; round(24,y,sx-24,y+h-8,0xff203650);
            text((i+1)+". "+names[i],sx/2,y+h/2+7,18,Color.WHITE);
            int best=pref.getInt("done"+i,0); text(best==1?"✓ تکمیل شده":"شروع",sx-68,y+h/2+7,12,0xff75dfc2);
          }
          text("پیشرفت و امتیاز روی همین دستگاه ذخیره می‌شود",sx/2,sy-16,11,0xff9cc9d5);
        }
        void play(){
          text("مرحله "+(stage+1)+" : "+names[stage],sx/2,145,20,Color.WHITE);
          if(completed){text("آفرین! مأموریت کامل شد",sx/2,230,24,0xff75dfc2);text("امتیاز این مرحله: "+score,sx/2,275,19,Color.WHITE);
            button("بازگشت به مراحل",sy*.70f,0xff167d79);return;}
          text("چالش "+(task+1)+" از 4",sx/2,190,16,0xff9cc9d5);
          round(22,215,sx-22,sy*.48f,0xff203650);
          String question=questionFor(stage,task);
          textLines(question,sx/2,265,21,Color.WHITE,(int)(sx-70));
          for(int i=0;i<3;i++){float y=sy*.52f+i*76; round(28,y,sx-28,y+58,selected==i?0xff167d79:0xff29425f); text(optsFor(stage,task,optionOrder[i]),sx/2,y+37,16,Color.WHITE);}
          if(!feedback.isEmpty()){text(feedback,sx/2,sy*.84f,14,0xffffd27a);}
          text("امتیاز: "+score+"   خطا: "+mistakes,sx/2,sy-25,13,0xffb8c8d8);
        }
        String questionFor(int s,int t){
          if(t==0)return qs[s][0];
          if(s==7){String[] q={"برای شروع ساخت ربات، کدام بخش پایه و نگهدارنده قطعات است؟","کدام قطعه به ربات کمک می‌کند مانع را تشخیص دهد؟","موتور و چرخ‌ها چه کاری انجام می‌دهند؟","اگر ربات به سمت مانع حرکت کرد، چه فرمانی ایمن‌تر است؟"};return q[t%4];}
          String[][] extra={
            {"کلید در مدار چه کاری می‌کند؟","روشن و خاموش کردن مدار","ذخیره برق","تولید نور"},
            {"موتور برقی چه چیزی را به حرکت تبدیل می‌کند؟","انرژی الکتریکی","آب آشامیدنی","نور چراغ"},
            {"برای تولید برق در شب چه کمکی می‌کند؟","باتری ذخیره‌ساز","پنجره","رنگ پنل"},
            {"در جاده لغزنده چه می‌کنی؟","آرام‌تر رانندگی می‌کنم","ترمز ناگهانی می‌زنم","شتاب می‌گیرم"},
            {"نمونه علمی را چگونه جمع می‌کنی؟","با بازوی نمونه‌بردار","با دست بدون محافظ","با پرتاب کردن"},
            {"پیامی که رمز عبور می‌خواهد مشکوک است؟","بله، اطلاعات را نمی‌دهم","نه، رمز را می‌فرستم","برای همه بازنشر می‌کنم"},
            {"اگر پیشنهاد هوش مصنوعی خطرناک بود چه می‌کنی؟","متوقف می‌شوم و با انسان بررسی می‌کنم","بدون بررسی اجرا می‌کنم","هشدار را نادیده می‌گیرم"}
          }; return extra[s][t%4];
        }
        String optsFor(int s,int t,int i){
          if(t==0)return opts[s][i];
          if(s==7){String[][] robot={{"شاسی و بدنه ربات","چراغ تزئینی","برچسب رنگی"},{"حسگر فاصله","بلندگوی موسیقی","چراغ تزئینی"},{"حرکت دادن ربات","ذخیره عکس","تغییر رنگ بدنه"},{"توقف و بررسی مسیر","سرعت بیشتر","نادیده گرفتن مانع"}};return robot[t%4][i];}
          String[][] a={
            {"روشن و خاموش کردن مدار","ذخیره برق","تولید نور"},
            {"انرژی الکتریکی","آب آشامیدنی","نور چراغ"},
            {"باتری ذخیره‌ساز","پنجره","رنگ پنل"},
            {"آرام‌تر رانندگی می‌کنم","ترمز ناگهانی می‌زنم","شتاب می‌گیرم"},
            {"با بازوی نمونه‌بردار","با دست بدون محافظ","با پرتاب کردن"},
            {"بله، اطلاعات را نمی‌دهم","نه، رمز را می‌فرستم","برای همه بازنشر می‌کنم"},
            {"داده مناسب و بررسی انسان","حدس بدون اطلاعات","اطلاعات شخصی همه افراد"},
            {"شاسی و بدنه ربات","چرخ یدکی خودرو","پنل خورشیدی"}
          };return a[s][i];
        }
        int answerFor(int s,int t){return 0;}
        void textLines(String str,float x,float y,int size,int color,int width){
          p.setTextSize(size);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setColor(color);
          String[] words=str.split(" ");String line="";int yy=0;
          for(String w:words){String test=line.isEmpty()?w:line+" "+w;if(p.measureText(test)>width){c.drawText(line,x,y+yy,p);line=w;yy+=size+9;}else line=test;}
          if(!line.isEmpty())c.drawText(line,x,y+yy,p);
        }
        void button(String s,float y,int color){round(35,y,sx-35,y+62,color);text(s,sx/2,y+39,18,Color.WHITE);}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
          if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY();
          if(stage<0){float h=Math.min(66,(sy-235)/8f);int i=(int)((y-205)/h);if(i>=0&&i<8){stage=i;task=0;score=0;mistakes=0;completed=false;feedback="";shuffleOptions();}invalidate();return true;}
          if(completed){stage=-1;invalidate();return true;}
          int pick=(int)((y-sy*.52f)/76);if(pick>=0&&pick<3){
            if(optionOrder[pick]==answerFor(stage,task)){score+=10;feedback="درست است! "+explain[stage];task++;if(task>=4){completed=true;pref.edit().putInt("done"+stage,1).putInt("score"+stage,score).apply();}else{shuffleOptions();}}
            else{mistakes++;feedback="یک بار دیگر فکر کن؛ پاسخ درست را پیدا کن.";}
            invalidate();
          }return true;
        }
    }
}